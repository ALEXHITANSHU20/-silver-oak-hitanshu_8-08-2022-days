let name=prompt("What is your name?");
document.write(name);