let a=10,b=200;
var c=a+b;
console.log("Sum of a+b is:",c);
document.write("Sum of a+b is: ",c);
